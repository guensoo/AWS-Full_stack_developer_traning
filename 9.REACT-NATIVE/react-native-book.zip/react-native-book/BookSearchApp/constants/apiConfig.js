// 클라이언트 ID, 시크릿 키

export const ClientID = 'ziGXIqTLlSbkc0RPgYH4';
export const ClientSecret = 'AEqBlAQuvd';