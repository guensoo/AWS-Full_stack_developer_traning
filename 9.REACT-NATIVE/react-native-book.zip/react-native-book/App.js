import App from './BookSearchApp/App';

export default App;
